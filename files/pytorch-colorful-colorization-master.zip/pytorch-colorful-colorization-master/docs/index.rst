This document is simply a collection of HTML pages for every documented module
in our project. If everything is working as expected, the documentation found
here should be automatically updated whenever changes to existing docstrings
are committed to the master branch.

Modules
============
.. toctree::
   :maxdepth: 2

   modules/index
