local test = require 'test_identifiers'

test.test_a_func()
test.test_func_b()

test.test_func_1()
test.test_too_func_2_furious()

test.test_foo_bar()
test.test_bar_foo()

test.test_l4()
test.test_l4_re()
test.test_l4_virtio()
test.test_l4_func()
