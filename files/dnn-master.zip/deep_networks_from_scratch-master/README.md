# Deep Neural Networks From Scratch

From scratch implementation of commen deep neural network architectures,
including hand written gradient optimization code. See `lib/` for network
implementations, `notebooks` for usage examples and `report/` for more detailed
investigations into the networks performances accompanying the respective
notebooks.
