annealed_mean_decode_q
======================
.. automodule:: colorization.modules.annealed_mean_decode_q
   :members:

colorization_network
====================
.. automodule:: colorization.modules.colorization_network
   :members:

conv2d_pad_same
===============
.. automodule:: colorization.modules.conv2d_pad_same
   :members:

cross_entropy_loss_2d
=====================
.. automodule:: colorization.modules.cross_entropy_loss_2d
   :members:

encode_ab
=========
.. automodule:: colorization.modules.encode_ab
   :members:
