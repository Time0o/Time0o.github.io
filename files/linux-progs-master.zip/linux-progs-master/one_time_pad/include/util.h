#ifndef UTIL_H
#define UTIL_H

int errprintf(char const *msg, ...);

long strtol_safe(char *str);

#endif /* UTIL_H */
