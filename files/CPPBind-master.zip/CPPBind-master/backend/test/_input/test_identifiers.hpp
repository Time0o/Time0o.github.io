namespace test
{

void AFunc() {}
void FuncB() {}

void Func1() {}
void TooFunc2Furious() {}

void FooBAR() {}
void BARFoo() {}

void L4() {}
void L4Re() {}
void L4virtio() {}
void l4_func() {}

// XXX mixed snake and pascal case

} // namespace test
