#ifndef PROTO_H
#define PROTO_H

enum proto { PROTO_ENC, PROTO_DEC };

#endif /* PROTO_H */
