module Diceprob.Bool (fromBool) where

fromBool :: Bool -> Int
fromBool = fromEnum
