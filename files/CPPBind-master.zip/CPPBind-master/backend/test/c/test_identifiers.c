#include <assert.h>

#include "test_identifiers_c.h"

int main()
{
  test_a_func();
  test_func_b();

  test_func_1();
  test_too_func_2_furious();

  test_foo_bar();
  test_bar_foo();

  test_l4();
  test_l4_re();
  test_l4_virtio();
  test_l4_func();

  return 0;
}
