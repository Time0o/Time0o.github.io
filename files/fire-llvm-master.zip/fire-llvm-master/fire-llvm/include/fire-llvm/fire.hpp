#pragma once

#include <fire-hpp/fire.hpp>

namespace fire {

template<typename T>
void fire_llvm(T&&) {}

} // end namespace fire
