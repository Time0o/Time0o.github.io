#pragma once

#ifndef KMEANS_MAX_ITER
  #define KMEANS_MAX_ITER 100
#endif
#ifndef KMEANS_CUDA_BLOCKSIZE
  #define KMEANS_CUDA_BLOCKSIZE 256
#endif
